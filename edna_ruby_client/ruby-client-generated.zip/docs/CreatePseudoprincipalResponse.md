# SwaggerClient::CreatePseudoprincipalResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**uid** | **String** |  | 
**row** | [**Array&lt;APIRowVal&gt;**](APIRowVal.md) |  | 

