# SwaggerClient::EndDisguiseResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**locators** | **Hash&lt;String, Array&lt;APILocator&gt;&gt;** |  | 

