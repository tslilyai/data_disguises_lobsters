# SwaggerClient::ApplyDisguiseResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**did** | **Integer** |  | 
**locators** | **Hash&lt;String, Array&lt;APILocCap&gt;&gt;** |  | 

