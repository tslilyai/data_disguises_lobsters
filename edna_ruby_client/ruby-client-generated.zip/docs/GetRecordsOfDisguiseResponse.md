# SwaggerClient::GetRecordsOfDisguiseResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**diff_records** | **Array&lt;Array&lt;Integer&gt;&gt;** |  | 
**ownership_records** | **Array&lt;Array&lt;Integer&gt;&gt;** |  | 

