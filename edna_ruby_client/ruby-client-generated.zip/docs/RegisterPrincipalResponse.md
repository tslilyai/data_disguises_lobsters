# SwaggerClient::RegisterPrincipalResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**privkey** | **String** |  | 

