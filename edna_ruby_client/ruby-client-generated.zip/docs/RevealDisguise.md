# SwaggerClient::RevealDisguise

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**tableinfo_json** | **String** |  | 
**guisegen_json** | **String** |  | 
**password** | **String** |  | 
**locators** | [**Array&lt;APILocator&gt;**](APILocator.md) |  | 

