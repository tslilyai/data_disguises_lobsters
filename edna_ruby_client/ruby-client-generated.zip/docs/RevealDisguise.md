# SwaggerClient::RevealDisguise

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**tableinfo_json** | **String** |  | 
**guisegen_json** | **String** |  | 
**decrypt_cap** | **Array&lt;Integer&gt;** |  | 
**locators** | [**Array&lt;APILocator&gt;**](APILocator.md) |  | 

