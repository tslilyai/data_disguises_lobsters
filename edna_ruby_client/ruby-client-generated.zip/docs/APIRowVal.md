# SwaggerClient::APIRowVal

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**column** | **String** |  | 
**value** | **String** |  | 

