# SwaggerClient::APILocator

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**loc** | **Integer** |  | 
**uid** | **String** |  | 
**did** | **Integer** |  | 

