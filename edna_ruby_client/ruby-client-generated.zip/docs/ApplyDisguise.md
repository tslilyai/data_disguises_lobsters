# SwaggerClient::ApplyDisguise

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**disguise_json** | **String** |  | 
**tableinfo_json** | **String** |  | 
**decrypt_cap** | **Array&lt;Integer&gt;** |  | 
**locators** | [**Array&lt;APILocCap&gt;**](APILocCap.md) |  | 

