# SwaggerClient::GetPseudoprincipals

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**decrypt_cap** | **Array&lt;Integer&gt;** |  | 
**ownership_locators** | [**Array&lt;APILocator&gt;**](APILocator.md) |  | 

