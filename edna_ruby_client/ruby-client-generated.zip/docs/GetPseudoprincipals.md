# SwaggerClient::GetPseudoprincipals

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**password** | **String** |  | 
**ownership_locators** | [**Array&lt;APILocator&gt;**](APILocator.md) |  | 

